package pkg71_ordenar_arraylist;

import java.util.Objects;

public class Avion implements Comparable<Avion> {

    // Atributos
    private String modelo;
    private int nAsientos;
    private double velocidadMaxima;

    // Constructores
    public Avion() {
        this("", 0, 0);
    }

    public Avion(String modelo, int nAsientos, double velocidadMaxima) {
        this.modelo = modelo;
        this.nAsientos = nAsientos;
        this.velocidadMaxima = velocidadMaxima;
    }

    // Metodos o propiedades
    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getnAsientos() {
        return nAsientos;
    }

    public void setnAsientos(int nAsientos) {
        this.nAsientos = nAsientos;
    }

    public double getVelocidadMaxima() {
        return velocidadMaxima;
    }

    public void setVelocidadMaxima(double velocidadMaxima) {
        this.velocidadMaxima = velocidadMaxima;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Avion other = (Avion) obj;
        if (!Objects.equals(this.modelo, other.modelo)) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Avion o) {

        if (this.velocidadMaxima>o.velocidadMaxima) {
            return 1;
        } else if (this.velocidadMaxima<o.velocidadMaxima) {
            return -1;
        } else {
            return 0;
        }

    }

    @Override
    public String toString() {
        return "Avion{" + "modelo=" + modelo + ", nAsientos=" + nAsientos + ", velocidadMaxima=" + velocidadMaxima + '}';
    }

}
