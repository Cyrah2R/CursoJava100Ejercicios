package pkg71_ordenar_arraylist;

import java.util.ArrayList;
import java.util.Collections;

/*
    Crea un ArrayList de Aviones y ordenalos de menor a mayor.
    Un avion es mayor que otro cuando su velocidad es mayor.
 */
public class OrdenarArrayList {

    public static void main(String[] args) {
        ArrayList<Avion> aviones = new ArrayList<>();

        Avion a3 = new Avion("Boing 789", 300, 600);
        Avion a1 = new Avion("Boing 123", 100, 1200);
        Avion a2 = new Avion("Boing 456", 200, 400);

        
        aviones.add(a3);
        aviones.add(a1);
        aviones.add(a2);

        Collections.sort(aviones);

        for (Avion a : aviones) {
            System.out.println(a);
        }

    }

}
