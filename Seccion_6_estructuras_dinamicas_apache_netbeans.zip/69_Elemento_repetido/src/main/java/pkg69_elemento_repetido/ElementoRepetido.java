package pkg69_elemento_repetido;

import java.util.ArrayList;

/*
    Usando la clase Avion que hicimos, crea un ArrayList y crea 3 aviones 
    y metelos en el ArrayList.
    Crea un avion más e indica si ya existe dentro del ArrayList.
    Un avión es igual a otro cuando el modelo es igual.
 */
public class ElementoRepetido {

    public static void main(String[] args) {

        ArrayList<Avion> aviones = new ArrayList<>();

        Avion a1 = new Avion("Boing 123", 100, 200);
        Avion a2 = new Avion("Boing 456", 200, 400);
        Avion a3 = new Avion("Boing 789", 300, 600);

        aviones.add(a1);
        aviones.add(a2);
        aviones.add(a3);

        Avion a4 = new Avion("Boing 123", 300, 600);
        
        if (aviones.contains(a4)) {
            System.out.println("Existe");
        } else {
            System.out.println("No existe");
        }

    }

}
