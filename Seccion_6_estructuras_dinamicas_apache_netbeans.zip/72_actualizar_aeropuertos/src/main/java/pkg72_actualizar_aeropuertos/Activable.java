package pkg72_actualizar_aeropuertos;

public interface Activable {
    
    public boolean isActivado();
    
    public void setActivado(boolean value);
    
}
