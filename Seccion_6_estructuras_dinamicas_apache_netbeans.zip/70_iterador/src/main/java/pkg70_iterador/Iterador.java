package pkg70_iterador;

import java.util.ArrayList;
import java.util.Iterator;

public class Iterador {

    /*
        Recorre un ArrayList por medio de un iterador.
    */
    public static void main(String[] args) {
        ArrayList<Avion> aviones = new ArrayList<>();

        Avion a1 = new Avion("Boing 123", 100, 200);
        Avion a2 = new Avion("Boing 456", 200, 400);
        Avion a3 = new Avion("Boing 789", 300, 600);

        aviones.add(a1);
        aviones.add(a2);
        aviones.add(a3);
        
        Iterator<Avion> it = aviones.iterator();
        
        Avion a;
        while(it.hasNext()){
            a = it.next();
            
            System.out.println(a);
            
        }
        
    }

}
