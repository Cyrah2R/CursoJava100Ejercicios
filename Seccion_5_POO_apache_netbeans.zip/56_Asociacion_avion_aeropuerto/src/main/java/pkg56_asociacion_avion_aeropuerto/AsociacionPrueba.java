package pkg56_asociacion_avion_aeropuerto;

public class AsociacionPrueba {

    public static void main(String[] args) {
       
        Direccion d = new Direccion("España", "mentiras", 1, "Ciudad real");

        Aeropuerto a = new Aeropuerto("Quijote airport", d, 2000, 1000);

        Avion av = new Avion("Boing 347", 200, 400);
        
        Avion av2 = new Avion("Boing 743", 300, 200);
        
        a.aniadirAvion(av);
        a.aniadirAvion(av2);
        
        System.out.println(a.getNumero_aviones());
        
        System.out.println(a);
    
    
    }
    
}
