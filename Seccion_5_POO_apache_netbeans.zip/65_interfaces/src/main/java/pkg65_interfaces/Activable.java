package pkg65_interfaces;

public interface Activable {
    
    public boolean isActivado();
    
    public void setActivado(boolean value);
    
}
