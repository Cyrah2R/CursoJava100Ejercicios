package pkg21_suma_1_n;

public class Suma1N {

    /*
        Crear una función que me devuelva la suma del 1 al numero pasado 
        por parámetro (este incluido).
     */
    public static void main(String[] args) {

        int n = 10;

        // 1º forma de llamada
        int res = suma1N(n);

        System.out.println(res);

        // 2º forma de llamada
        System.out.println(suma1N(n));

    }

    public static void met1(int p1, int p2, String p3) {
        // Acciones
    }

    public static int suma1N(int n) {

        int suma = 0;

        for (int i = 1; i <= n; i++) {
            suma += i;
        }

        return suma;

    }

}
