package pkg29_digito_mas_alto;

public class DigitoMasAlto {

    /*
        Crea una función que dado un numero, decir cual es el dígito 
        mas alto que tiene.
     */
    public static void main(String[] args) {
        System.out.println(digitoMasAlto(5218));
    }

    public static int digitoMasAlto(int numero) {

        final int DIVISOR = 10;

        int mayor = 0;

        for (int i = numero; i > 0; i /= DIVISOR) {

            if ((i % DIVISOR) > mayor) {
                mayor = i % DIVISOR;
            }

        }

        return mayor;

    }

}
