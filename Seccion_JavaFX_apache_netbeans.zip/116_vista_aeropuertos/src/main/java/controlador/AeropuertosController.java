/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;

/**
 * FXML Controller class
 *
 * @author Fernando
 */
public class AeropuertosController implements Initializable {

    @FXML
    private TableView<?> tblAeropuertos;
    @FXML
    private TableColumn<?, ?> colId;
    @FXML
    private TableColumn<?, ?> colNombre;
    @FXML
    private TableColumn<?, ?> colPais;
    @FXML
    private TableColumn<?, ?> colCiudad;
    @FXML
    private TableColumn<?, ?> colCalle;
    @FXML
    private TableColumn<?, ?> colNumero;
    @FXML
    private TableColumn<?, ?> colAnio;
    @FXML
    private TableColumn<?, ?> colCapacidad;
    @FXML
    private TableColumn<?, ?> colSocios;
    @FXML
    private TableColumn<?, ?> colFinanciacion;
    @FXML
    private TableColumn<?, ?> colDiscapacitados;
    @FXML
    private RadioButton rdbPrivados;
    @FXML
    private RadioButton rdbPublicos;
    @FXML
    private TextField txtFiltroNombre;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void cambiarAeropuertosPrivados(ActionEvent event) {
    }

    @FXML
    private void cambiarAeropuertosPublicos(ActionEvent event) {
    }

    @FXML
    private void AniadirAeropuerto(ActionEvent event) {
    }

    @FXML
    private void editarAeropuerto(ActionEvent event) {
    }

    @FXML
    private void borrarAeropuerto(ActionEvent event) {
    }

    @FXML
    private void gananciasAeropuerto(ActionEvent event) {
    }

    @FXML
    private void infoAeropuerto(ActionEvent event) {
    }

    @FXML
    private void aniadirAvion(ActionEvent event) {
    }

    @FXML
    private void activarDesactivarAvion(ActionEvent event) {
    }

    @FXML
    private void BorrarAvion(ActionEvent event) {
    }

    @FXML
    private void filtroPorNombre(KeyEvent event) {
    }
    
}
