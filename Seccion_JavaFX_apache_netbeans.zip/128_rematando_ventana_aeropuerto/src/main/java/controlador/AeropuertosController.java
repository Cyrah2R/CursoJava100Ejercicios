/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;
import modelo.Aeropuerto;
import modelo.AeropuertoPrivado;
import modelo.AeropuertoPublico;

public class AeropuertosController implements Initializable {

    @FXML
    private TableView tblAeropuertos;
    @FXML
    private TableColumn<Aeropuerto, Integer> colId;
    @FXML
    private TableColumn<Aeropuerto, String> colNombre;
    @FXML
    private TableColumn<Aeropuerto, String> colPais;
    @FXML
    private TableColumn<Aeropuerto, String> colCiudad;
    @FXML
    private TableColumn<Aeropuerto, String> colCalle;
    @FXML
    private TableColumn<Aeropuerto, Integer> colNumero;
    @FXML
    private TableColumn<Aeropuerto, Integer> colAnio;
    @FXML
    private TableColumn<Aeropuerto, Integer> colCapacidad;
    @FXML
    private TableColumn<Aeropuerto, Integer> colSocios;
    @FXML
    private TableColumn<Aeropuerto, Double> colFinanciacion;
    @FXML
    private TableColumn<Aeropuerto, Integer> colDiscapacitados;
    @FXML
    private RadioButton rdbPrivados;
    @FXML
    private RadioButton rdbPublicos;
    @FXML
    private TextField txtFiltroNombre;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        // Sirve para relacionar radio button
        ToggleGroup group = new ToggleGroup();

        // indico que estan relacionados
        this.rdbPrivados.setToggleGroup(group);
        this.rdbPublicos.setToggleGroup(group);

        // Asocio las columnas con las propiedades del objeto
        this.colId.setCellValueFactory(new PropertyValueFactory("id"));
        this.colNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.colPais.setCellValueFactory(new PropertyValueFactory("pais"));
        this.colCiudad.setCellValueFactory(new PropertyValueFactory("ciudad"));
        this.colCalle.setCellValueFactory(new PropertyValueFactory("calle"));
        this.colNumero.setCellValueFactory(new PropertyValueFactory("numero"));
        this.colAnio.setCellValueFactory(new PropertyValueFactory("anioInauguracion"));
        this.colCapacidad.setCellValueFactory(new PropertyValueFactory("capacidad"));
        this.colSocios.setCellValueFactory(new PropertyValueFactory("numSocios"));
        this.colFinanciacion.setCellValueFactory(new PropertyValueFactory("financiacion"));
        this.colDiscapacitados.setCellValueFactory(new PropertyValueFactory("numTrabajadoresDiscapacitados"));

        // Cargo los aeropuertos al iniciar
        this.cargarAeropuertos();
    }

    /**
     * Carga los aeropuertos privados
     *
     * @param event
     */
    @FXML
    private void cambiarAeropuertosPrivados(ActionEvent event) {
        this.cargarAeropuertos();
    }

    /**
     * Carga los aeropuertos publicos
     *
     * @param event
     */
    @FXML
    private void cambiarAeropuertosPublicos(ActionEvent event) {
        this.cargarAeropuertos();
    }

    @FXML
    private void AniadirAeropuerto(ActionEvent event) {

        try {
            // carga la vista
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/vista/AeropuertoVista.fxml"));

            // Cargo el padre
            Parent root = loader.load();

            // Creo la scene
            Scene scene = new Scene(root);

            // Creo la stage
            Stage stage = new Stage();

            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(scene);
            stage.setTitle("Añadir aeropuerto");
            stage.showAndWait();
            
            // cargo los aeropuertos de nuevo
            this.cargarAeropuertos();

        } catch (IOException ex) {
            Logger.getLogger(AeropuertosController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @FXML
    private void editarAeropuerto(ActionEvent event) {
    }

    @FXML
    private void borrarAeropuerto(ActionEvent event) {
    }

    @FXML
    private void gananciasAeropuerto(ActionEvent event) {
    }

    @FXML
    private void infoAeropuerto(ActionEvent event) {
    }

    @FXML
    private void aniadirAvion(ActionEvent event) {
    }

    @FXML
    private void activarDesactivarAvion(ActionEvent event) {
    }

    @FXML
    private void BorrarAvion(ActionEvent event) {
    }

    @FXML
    private void filtroPorNombre(KeyEvent event) {
        this.cargarAeropuertos();
    }

    /**
     * Cargo los aeropuertos segun el filtro seleccionado
     */
    private void cargarAeropuertos() {
        try {

            String busqueda = this.txtFiltroNombre.getText();

            // Si el radio de privados esta seleccionado
            if (this.rdbPrivados.isSelected()) {

                // Cargo los aeropuertos privados
                AeropuertoPrivado ap = new AeropuertoPrivado();
                ObservableList<AeropuertoPrivado> obs = ap.getAeropuertos(busqueda);
                this.tblAeropuertos.setItems(obs);

                // Muestro la columna de socios
                this.colSocios.setVisible(true);

                //Oculto las columnas de financiacion y discapacitados
                this.colFinanciacion.setVisible(false);
                this.colDiscapacitados.setVisible(false);

            } else {

                // Cargo los aeropuertos publicos
                AeropuertoPublico ap = new AeropuertoPublico();
                ObservableList<AeropuertoPublico> obs = ap.getAeropuertos(busqueda);
                this.tblAeropuertos.setItems(obs);

                // Oculta la columna de socios
                this.colSocios.setVisible(false);

                // Muestro las columnas de financiacion y discapacitados
                this.colFinanciacion.setVisible(true);
                this.colDiscapacitados.setVisible(true);

            }

        } catch (SQLException ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setTitle("Error");
            alert.setContentText(ex.getMessage());
            alert.showAndWait();
        }

    }

}
