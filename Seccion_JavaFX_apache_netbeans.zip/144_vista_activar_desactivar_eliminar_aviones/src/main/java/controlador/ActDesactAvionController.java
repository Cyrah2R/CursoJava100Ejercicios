
package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.RadioButton;

public class ActDesactAvionController implements Initializable {

    @FXML
    private ComboBox<?> cmbAeropuertos;
    @FXML
    private ComboBox<?> cmbAviones;
    @FXML
    private Button btnActualizar;
    @FXML
    private Button btnCancelar;
    @FXML
    private RadioButton rdbActivado;
    @FXML
    private RadioButton rdbDesactivado;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void cargarAviones(ActionEvent event) {
    }

    @FXML
    private void seleccionarActivado(ActionEvent event) {
    }

    @FXML
    private void actualizarAvion(ActionEvent event) {
    }

    @FXML
    private void cancelar(ActionEvent event) {
    }
    
}
