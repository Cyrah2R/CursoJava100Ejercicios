/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class AeropuertoController implements Initializable {

    @FXML
    private TextField txtNombre;
    @FXML
    private Button btnCancelar;
    @FXML
    private Button btnGuardar;
    @FXML
    private TextField txtPais;
    @FXML
    private TextField txtCiudad;
    @FXML
    private TextField txtCalle;
    @FXML
    private TextField txtNumero;
    @FXML
    private TextField txtAnio;
    @FXML
    private TextField txtCapacidad;
    @FXML
    private TextField txtFinanciacion;
    @FXML
    private TextField txtDiscapacitados;
    @FXML
    private TextField txtSocios;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    /**
     * Cierra la ventana
     *
     * @param event
     */
    @FXML
    private void cancelar(ActionEvent event) {
        // Cierro la ventana
        Stage myStage = (Stage) this.btnCancelar.getScene().getWindow();
        myStage.close();
    }

    /**
     * Inserta o edita el aeropuerto
     *
     * @param event
     */
    @FXML
    private void guardar(ActionEvent event) {
    }

}
