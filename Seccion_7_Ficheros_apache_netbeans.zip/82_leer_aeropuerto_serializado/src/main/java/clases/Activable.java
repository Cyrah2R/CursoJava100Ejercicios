package clases;

public interface Activable {
    
    public boolean isActivado();
    
    public void setActivado(boolean value);
    
}
