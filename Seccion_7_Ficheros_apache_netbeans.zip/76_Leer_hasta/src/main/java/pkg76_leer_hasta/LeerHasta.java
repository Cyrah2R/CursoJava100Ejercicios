package pkg76_leer_hasta;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LeerHasta {

    /*
        Create un fichero de texto tu mismo, pide un numero de lineas y 
        lee hasta ese numero de lineas.
        Si el numero que te dan es un numero negativo o se leen mas lineas 
        de las que hay, lanza una excepción.
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Escribe el numero de lineas");
        System.out.println("Debe ser positivo y no mas de las lineas que hay en el fichero");
        int numLineasLeer = sc.nextInt();

        try (BufferedReader br = new BufferedReader(new FileReader("fichero.txt"))) {
            int numLineasFichero = cuentaLineas("fichero.txt");

            if (numLineasLeer < 0 || numLineasLeer > numLineasFichero) {
                throw new IOException("No puedes leer " + numLineasLeer + " lineas");
            }

            // Si llego aqui es que es correcto
            String linea = "";
            for (int i = 0; i < numLineasLeer && (linea = br.readLine()) != null; i++) {
                System.out.println(linea);
            }

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static int cuentaLineas(String fichero) throws FileNotFoundException, IOException {
        int contador = 0;

        BufferedReader br = new BufferedReader(new FileReader(fichero));
        String linea = "";
        while ((linea = br.readLine()) != null) {
            contador++;
        }

        return contador;
    }

}
