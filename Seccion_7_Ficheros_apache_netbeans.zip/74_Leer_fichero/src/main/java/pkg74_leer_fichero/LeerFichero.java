package pkg74_leer_fichero;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LeerFichero {

    /*
        Create un fichero en el proyecto tu mismo y escribele el texto que quieras.
        Léelo con BufferedReader.
        Haz una función de ello.
     */
    public static void main(String[] args) {

        try {
            leerFichero("fichero.txt");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

    public static void leerFichero(String fichero) throws FileNotFoundException, IOException {
        BufferedReader br = new BufferedReader(new FileReader(fichero));
            
        String linea = "";
        while ((linea = br.readLine()) != null) {
            System.out.println(linea);
        }

    }

}
