package pkg79_escribir_avion_dos;

public interface Activable {
    
    public boolean isActivado();
    
    public void setActivado(boolean value);
    
}
