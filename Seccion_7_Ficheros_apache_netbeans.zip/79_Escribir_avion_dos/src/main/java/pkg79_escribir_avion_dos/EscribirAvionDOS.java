package pkg79_escribir_avion_dos;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class EscribirAvionDOS {

    /*
        Escribe la información de un avión con DataOutputStream.
     */
    public static void main(String[] args) {

        Avion a = new Avion("Boing 123", 100, 1200);

        try (DataOutputStream dos = new DataOutputStream(new FileOutputStream("avion.ddr"))) {

            dos.writeUTF(a.getModelo());
            dos.writeInt(a.getnAsientos());
            dos.writeDouble(a.getVelocidadMaxima());

        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
