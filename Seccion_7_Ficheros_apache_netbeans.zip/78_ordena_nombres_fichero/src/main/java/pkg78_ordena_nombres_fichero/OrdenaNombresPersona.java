package pkg78_ordena_nombres_fichero;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class OrdenaNombresPersona {

    /*
        Escribe en un fichero nombres de personas tu mismo, leelo, guárdalos 
        en un ArrayList, ordena los nombres y escribelos en un nuevo fichero.
     */
    public static void main(String[] args) {

        ArrayList<String> nombres = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("nombres.txt"));
                BufferedWriter bw = new BufferedWriter(new FileWriter("nombre_ordenados.txt"))) {

            String linea;
            while ( (linea = br.readLine()) != null){
                nombres.add(linea);
            }
            
            Collections.sort(nombres);
            
            for (String nombre: nombres) {
                bw.write(nombre+"\r\n");
            }
            
            System.out.println("Se han ordenado los nombres");
            
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
