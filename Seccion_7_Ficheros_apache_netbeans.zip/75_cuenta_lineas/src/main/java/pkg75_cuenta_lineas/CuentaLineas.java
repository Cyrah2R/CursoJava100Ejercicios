package pkg75_cuenta_lineas;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CuentaLineas {

    /*
        Create un fichero de texto tu mismo y cuenta el numero de lineas 
        que tiene.
     */
    public static void main(String[] args) {

        int contador=0;
            
        try (BufferedReader br = new BufferedReader(new FileReader("fichero.txt"))) {

           String linea="";
           while( (linea = br.readLine()) != null ){
               contador++;
           }
            
        } catch (FileNotFoundException ex) {
            System.out.println(ex.getMessage());
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }

        System.out.println("Numero de lineas: "+contador);
        
        
    }

}
