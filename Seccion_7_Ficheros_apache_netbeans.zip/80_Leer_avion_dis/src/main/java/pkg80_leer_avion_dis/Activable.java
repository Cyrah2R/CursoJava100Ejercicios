package pkg80_leer_avion_dis;

public interface Activable {
    
    public boolean isActivado();
    
    public void setActivado(boolean value);
    
}
