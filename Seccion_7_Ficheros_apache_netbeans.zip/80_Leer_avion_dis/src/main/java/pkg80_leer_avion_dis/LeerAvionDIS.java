package pkg80_leer_avion_dis;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LeerAvionDIS {

    /*
        Lee la información del fichero anterior y crea el avión correspondiente.
     */
    public static void main(String[] args) {

        try (DataInputStream dis = new DataInputStream(new FileInputStream("avion.ddr"))) {

            String modelo = dis.readUTF();
            int nAsientos = dis.readInt();
            double velocidad = dis.readDouble();
            
            Avion a = new Avion(modelo, nAsientos, velocidad);
            
            System.out.println(a);
            
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(LeerAvionDIS.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(LeerAvionDIS.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

}
