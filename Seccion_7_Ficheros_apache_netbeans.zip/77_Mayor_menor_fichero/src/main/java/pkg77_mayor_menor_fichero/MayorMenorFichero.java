package pkg77_mayor_menor_fichero;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

public class MayorMenorFichero {

    /*
        Dado un fichero de texto con una lista de números, indica cual es 
        el mayor y el menor.
     */
    public static void main(String[] args) {

        try (BufferedReader br = new BufferedReader(new FileReader("fichero.txt"))) {
            int numLineas = cuentaLineas("fichero.txt");

            int numeros[] = new int[numLineas];

            String linea = "";

            for (int i = 0; (linea = br.readLine()) != null; i++) {
                numeros[i] = Integer.parseInt(linea);
            }

            Arrays.sort(numeros);

            System.out.println("El menor es: " + numeros[0]);
            System.out.println("El mayor es: " + numeros[numeros.length - 1]);

        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        } catch(NumberFormatException ex){
            System.out.println("No se puede convertir algun dato en numero. Revisa el fichero." +ex.getMessage());
        }

    }

    public static int cuentaLineas(String fichero) throws FileNotFoundException, IOException {
        int contador = 0;

        BufferedReader br = new BufferedReader(new FileReader(fichero));
        String linea = "";
        while ((linea = br.readLine()) != null) {
            contador++;
        }

        return contador;
    }

}
