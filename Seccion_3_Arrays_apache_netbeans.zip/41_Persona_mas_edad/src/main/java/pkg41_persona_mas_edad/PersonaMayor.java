package pkg41_persona_mas_edad;

public class PersonaMayor {

    /*
        Teniendo un array de String con el nombre de personas y otro de 
        números con su edad, indicar quien es la persona mas mayor.
     */
    public static void main(String[] args) {

        String[] nombres = {"Fernando", "Jaime", "Alberto", "Pepito"};
        int[] edades = {28, 31, 20, 10};

        int edadMayor = edades[0];
        int posicionMayor = 0;
        
        for (int i = 1; i < edades.length; i++) {

            if(edades[i] > edadMayor){
                edadMayor = edades[i];
                posicionMayor = i;
            }
            
        }
        
        System.out.println("La persona mas mayor es "+nombres[posicionMayor]+" con "+edadMayor);
        
        
    }

}
