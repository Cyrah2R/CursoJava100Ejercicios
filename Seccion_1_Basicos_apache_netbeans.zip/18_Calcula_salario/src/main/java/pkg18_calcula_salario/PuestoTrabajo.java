
package pkg18_calcula_salario;

public enum PuestoTrabajo {
    VENDEDOR,
    DIRECTOR,
    CONSERJE;
}
