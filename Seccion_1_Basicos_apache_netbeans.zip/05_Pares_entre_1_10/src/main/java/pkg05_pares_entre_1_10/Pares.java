package pkg05_pares_entre_1_10;

public class Pares {

    /*
        Mostrar los números pares que hay entre el 1 y 10 (while y for).
     */
    public static void main(String[] args) {

        // While
        System.out.println("While");
        System.out.println("-----");

        int i = 1;
        while (i <= 10) {
            if (i % 2 == 0) {
                System.out.println(i);
            }
            i++; // i = i + 1
        }

        // For
        System.out.println("For");
        System.out.println("---");

        for (int j = 0; j <= 10; j++) {
            if (j % 2 == 0) {
                System.out.println(j);
            }
        }

        // For (2º forma)
        // Con while tambien se puede hacer
        System.out.println("For (2º forma)");
        System.out.println("---");
        for (int j = 2; j <= 10; j += 2) {
            System.out.println(j);
        }
        
        // for y pulsas tab para generar un for
        
        
    }

}
