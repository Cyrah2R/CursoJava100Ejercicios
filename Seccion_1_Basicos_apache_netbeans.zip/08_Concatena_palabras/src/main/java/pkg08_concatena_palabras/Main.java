package pkg08_concatena_palabras;

import java.util.Scanner;

public class Main {

    /*
        Pedir palabras al usuario hasta que el usuario escriba una cadena vacía. 
        Muestra la concatenación de esas palabras al final.
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");

        System.out.println("Dame una cadena");
        String cadUsuario = sc.next();

        String concatenar = "";

        while (!cadUsuario.isEmpty()) { // !cadUsuario.equals("")

            concatenar += cadUsuario; // concatenar = concatenar + cadUsuario;

            System.out.println("Dame una cadena");
            cadUsuario = sc.next();

        }

        System.out.println(concatenar);

    }

}
