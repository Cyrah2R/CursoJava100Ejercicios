package pkg07_recorrer_cadena;

import java.util.Scanner;

public class RecorrerCadena {

    /*
        Pide una cadena por consola y muestra sus caracteres uno a uno.
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");

        System.out.println("Inserta una frase");
        String frase = sc.next();

        // h o l a
        // 0 1 2 3
        char caracter;
        for (int i = 0; i < frase.length(); i++) {
            caracter = frase.charAt(i);
            System.out.println(caracter);
        }

    }

}
