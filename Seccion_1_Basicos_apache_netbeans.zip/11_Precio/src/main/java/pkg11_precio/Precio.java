package pkg11_precio;

import java.util.Locale;
import java.util.Scanner;

public class Precio {

    /*
        Pide un número real que represente a un precio y muestra el 
        precio con IVA. El IVA es de 21%.
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        sc.useLocale(Locale.US);

        final double IVA = 0.21;

        System.out.println("Escribe un numero real");
        double precioSinIVA = sc.nextDouble();

        //double precioConIVA = precioSinIVA + (precioSinIVA * IVA);
        double precioConIVA = precioSinIVA * (1 + IVA);

        System.out.println("El precio final es de " + precioConIVA);

    }

}
