package pkg16_adivina_numero;

import java.util.Scanner;

public class AdivinaNumero {

    /*
        Vamos a jugar a un pequeño juego. 
        Vamos a generar un número aleatorio entre 1 y 100.
        Debes pedir al usuario números que estén entre estos dos números 
        (debes controlarlos).Si el usuario falla, debes indicarle si el 
        número que introdujo es mayor o menor que el que debe acertar.
        El programa termina cuando el usuario acierta. No hay limite de 
        intentos.
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int maximo = 100;
        int minimo = 1;

        int numeroAcertar = (int) (Math.random() * (maximo - minimo + 1) + (minimo));
        int numeroUsuario;

        boolean fin = false;

        while (!fin) {

            do {

                System.out.println("Dame un numero entre 1 y 100");
                numeroUsuario = sc.nextInt();

                if (!(numeroUsuario >= minimo && numeroUsuario <= maximo)) {
                    System.out.println("Debes escribir un numero entre " + minimo + " y " + maximo);
                }

            } while (!(numeroUsuario >= minimo && numeroUsuario <= maximo));

            if (numeroUsuario < numeroAcertar) {
                System.out.println("Es mayor que el que introdujiste");
            } else if (numeroUsuario > numeroAcertar) {
                System.out.println("Es menor que el que introdujiste");
            } else {
                System.out.println("¡Has acertado! El número era el " + numeroAcertar);
                fin = true;
            }

        }

    }

}
