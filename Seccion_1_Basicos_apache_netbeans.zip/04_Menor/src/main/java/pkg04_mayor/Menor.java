package pkg04_mayor;

import java.util.Scanner;

public class Menor {

    /*
        Pide 2 números por consola e indica cual es el menor de los 2 números. 
        En caso de que sean iguales, también lo debes indicar.
    */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        System.out.println("Inserta el primer numero");
        int num1 = sc.nextInt();
        
        System.out.println("Inserta el segundo numero");
        int num2 = sc.nextInt();
        
        if(num1 <= num2){
            if (num1 == num2) {
                System.out.println("El num1 y el num2 son iguales");
            } else {
                System.out.println("el num1 es menor que el num2");
            }
        }else{
            System.out.println("El num2 es menor que el num1");
        }
        
        
    }
    
}
