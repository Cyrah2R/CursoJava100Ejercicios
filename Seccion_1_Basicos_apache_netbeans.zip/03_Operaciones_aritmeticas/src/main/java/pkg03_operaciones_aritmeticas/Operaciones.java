package pkg03_operaciones_aritmeticas;

import java.util.Scanner;

public class Operaciones {

    /*
       Pide dos números por consola y muestra su suma, resta, multiplicación y división.
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Escribe el numero 1");
        int num1 = sc.nextInt();

        System.out.println("Escribe el numero 2");
        int num2 = sc.nextInt();

        int suma = num1 + num2;
        System.out.println("La suma es: " + suma);

        int resta = num1 - num2;
        System.out.println("La resta es: " + resta);

        int mult = num1 * num2;
        System.out.println("La multiplicacion es: " + mult);

        if (num2 == 0) {
            System.out.println("No puedes dividir entre 0");
        } else {
            double division = (double) num1 / num2;
            System.out.println("La division es: " + division);
        }

    }

}
