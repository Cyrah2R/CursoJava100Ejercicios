package pkg01_variables;

public class Variables {

    /*
        Crea una variable de cada tipo:
            - byte
            - short
            - int
            - long
            - char
            - double
            - float
            - String
            - boolean
    
    */
    public static void main(String[] args) {
       
        //numeros enteros
        byte a=5;
        short b = 200;
        int c = 1000000;
        long d = 10000000000L;
        
        //caracter
        char e = 'a';
        
        double f = 4.5;
        float g = 4.5f;
        
        String h = "Hola mundo";
        
        boolean i = 5 > 10;
        
        
    }
    
}
