package pkg15_palindromo;

import java.util.Scanner;

public class Palindromo {

    /*
        Pide una frase por consola e indica si es palindromo. 

        Es palindromo cuando se lee una frase igual de izquierda a derecha 
        que de derecha a izquierda. Por ejemplo, alola
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        sc.useDelimiter("\n");

        System.out.println("Escribe una frase o palabra");
        String frase = sc.next().trim();

        String invertida = "";

        char caracter;
        for (int i = frase.length() - 1; i >= 0; i--) {
            caracter = frase.charAt(i);
            System.out.println(caracter);
            invertida += caracter;
        }

        if (frase.equals(invertida)) {
            System.out.println("Es palindromo");
        } else {
            System.out.println("No es palindromo");
        }

    }

}
