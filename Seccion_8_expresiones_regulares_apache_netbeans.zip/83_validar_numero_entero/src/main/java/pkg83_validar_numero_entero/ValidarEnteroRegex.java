package pkg83_validar_numero_entero;

public class ValidarEnteroRegex {

    /*
        Validar si una cadena es un numero entero.
     */
    public static void main(String[] args) {
     
        if(validaNumeroEntero_Exp("10")){
            System.out.println("correcto");
        }else{
            System.out.println("no correcto");
        }
        
    }

    /**
     * Valida si una cadena es un numero entero
     *
     * @param texto String que contiene el valor a validar
     * @return True = es un numero entero
     */
    public static boolean validaNumeroEntero_Exp(String texto) {
        return texto.matches("^-?[0-9]+$");
    }

}
