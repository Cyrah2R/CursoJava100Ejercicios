package pkg84_validar_numero_real;

public class ValidarRealRegex {

    /*
        Validar si una cadena es un numero real.
     */
    public static void main(String[] args) {

        if(validaNumeroReal_Exp("-10.55")){
            System.out.println("correcto");
        }else{
            System.out.println("no correcto");
        }
        
    }

    /**
     * Valida si una cadena es un numero real (positivo o negativo)
     *
     * @param texto String que contiene el valor a validar
     * @return True = es un numero real
     */
    public static boolean validaNumeroReal_Exp(String texto) {
        return texto.matches("^-?[0-9]+([\\.,][0-9]+)?$");
    }

}
