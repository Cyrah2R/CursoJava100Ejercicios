package pkg102_recuperar_aeropuertos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RecuperarAeropuertos {

    /**
     * Recupera todos los aeropuertos y muestralos por consola.
     */
    public static void main(String[] args) {

        try {
            Connection conexion;

            // Adaptalos a tu conexion
            String host = "localhost";
            String baseDatos = "aeropuertos";
            String usuario = "root";
            String password = "";

            // Cadena de conexion para conectarnos a la base de datos en MySQL
            String cadenaConexion = "jdbc:mysql://" + host + "/" + baseDatos;

            // Creo la conexion 
            conexion = DriverManager.getConnection(cadenaConexion, usuario, password);

            // Hace commit automaticamente
            conexion.setAutoCommit(true);

            // Creo la sentencia
            Statement sentencia = conexion.createStatement();

            // Formo el SQL
            String SQL = "";
            SQL += "SELECT a.nombre, a.anio_inauguracion, a.capacidad, ";
            SQL += "d.pais, d.ciudad, d.calle, d.numero ";
            SQL += "FROM aeropuertos a, direcciones d ";
            SQL += "WHERE a.id_direccion = d.id";

            // Ejecuto el SQL y devuelvo los datos
            ResultSet rs = sentencia.executeQuery(SQL);

            // Recorro los datos
            while (rs.next()) {

                // Obtengo y muestro los datos de cada atributo
                System.out.println("Nombre:" + rs.getString("nombre"));
                System.out.println("Año de inauguracion:" + rs.getInt("anio_inauguracion"));
                System.out.println("Capacidad:" + rs.getInt("capacidad"));
                System.out.println("Pais:" + rs.getString("pais"));
                System.out.println("Ciudad:" + rs.getString("ciudad"));
                System.out.println("Calle:" + rs.getString("calle"));
                System.out.println("Número:" + rs.getString("numero"));
                System.out.println("");
            }

            // Cierro el resultset, la sentencia y la conexion
            rs.close();
            sentencia.close();
            conexion.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
