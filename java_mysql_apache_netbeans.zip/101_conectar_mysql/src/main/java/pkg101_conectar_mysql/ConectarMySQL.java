package pkg101_conectar_mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class ConectarMySQL {

    /**
     * Conecta Java con MySQL
     */
    public static void main(String[] args) {

        try {
            Connection conexion;

            // Adaptalos a tu conexion
            String host = "localhost";
            String baseDatos = "aeropuertos";
            String usuario = "root";
            String password = "";

            // Cadena de conexion para conectarnos a la base de datos en MySQL
            String cadenaConexion = "jdbc:mysql://" + host + "/" + baseDatos;
            
            // Creo la conexion 
            conexion = DriverManager.getConnection(cadenaConexion, usuario, password);
            
            // Hace commit automaticamente
            conexion.setAutoCommit(true);

            // Creo una sentencia
            Statement sentencia = conexion.createStatement();
            
            // Ejecuto el SQL
            sentencia.executeQuery("SELECT * FROM aeropuertos");

            // Cierro la sentencia y la conexion
            sentencia.close();
            conexion.close();

        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        }

    }

}
